<?php
/**
 * Project Loop Start
 *
 * @author 		WooThemes
 * @package 	Projects/Templates
 * @version     1.0.0
 */
?>
<ul class="projects">